// Grupo 21, CRISTHIAN RODRIGUEZ GOMEZ y JONATHAN CARRERO ARANDA

//para saber si un Arbol es AVL ademas de que sea equilibrado y ordenado al mismo tiempo

#include <iostream>
#include "Arbin.h"


using namespace std;

Arbin<int> leeArbol();
int altura(Arbin<int> arbol);
void resuelveCaso(Arbin<int> arbol);
int diferencia(int n , int m);
bool esOrdenado(Arbin<int> arbol);
bool tiene_2_Hijos(Arbin<int> arbol);
bool tiene_Hijo_Izq(Arbin<int> arbol);
bool tiene_Hijo_Dr(Arbin<int> arbol);
bool esEquilibrado(Arbin<int> arbol);
// lee un �rbol binariio de la entrada estandar
Arbin<int> leeArbol()
{
	int raiz;

	cin >> raiz;
	if(raiz==-1)
		return Arbin<int>();
	else
	{
		const Arbin<int> &iz = leeArbol();
		const Arbin<int> &dr = leeArbol();
		return Arbin<int>(iz, raiz, dr);
	}
}


// dado un �rbol binario, calcula si el arbol es AVL, O(LOG(n))
bool esOrdenado(Arbin<int> arbol){
	
	if(arbol.esVacio()){ 

		return true;

	}else if( tiene_2_Hijos(arbol)){

		if((arbol.raiz() > arbol.hijoIz().raiz()) && (arbol.hijoDr().raiz() > arbol.raiz())){

			return( esOrdenado(arbol.hijoIz()) &&			
			        esOrdenado(arbol.hijoDr()) 
				   );
		}else 
			return false;
	
	}else if(tiene_Hijo_Izq(arbol)){

		if (arbol.raiz() > arbol.hijoIz().raiz()){

			return ( esOrdenado(arbol.hijoIz() ));
		}else 
			return false;

	}else if(tiene_Hijo_Dr(arbol)){

		if (arbol.raiz() < arbol.hijoDr().raiz()){

			return ( esOrdenado(arbol.hijoDr())  );
		}else 
			return false;
	}
	else return true;
}

// dado un �rbol binario, calcula si el arbol es equilibrado, O(LOG(n))
bool esEquilibrado(Arbin<int> arbol){
	
	if(arbol.esVacio()) return true;
	else{
		return( esEquilibrado(arbol.hijoIz()) &&			
			    esEquilibrado(arbol.hijoDr()) && 
				diferencia(
						altura(arbol.hijoIz()),
						altura(arbol.hijoDr())
				) <=1
			  );
	}
}
//Resuelve un cado de prueba, leyendo de la entrada la
//configuracion, y escribiendo la respuesta
void resuelveCaso(){
	Arbin<int> arbol;

	arbol = leeArbol();
	
	if(esOrdenado(arbol) && esEquilibrado(arbol))
		cout <<"SI" << endl;
	else cout <<"NO" << endl;
} 




//--------------- Funciones Auxiliares------------------
bool tiene_2_Hijos(Arbin<int> arbol){
	return (!arbol.hijoIz().esVacio() && !arbol.hijoDr().esVacio());
}
bool tiene_Hijo_Izq(Arbin<int> arbol){
	return (!arbol.hijoIz().esVacio());
}
bool tiene_Hijo_Dr(Arbin<int> arbol){
	return (!arbol.hijoDr().esVacio());
}
// dado un �rbol binario, calcula la altura del arbol, O(N)
int altura(Arbin<int> arbol){
	if (arbol.esVacio()){
		return 0;
	}else{
		return 1 + max(altura(arbol.hijoIz()),altura(arbol.hijoDr()));
	}
}
// dados dos enteros nos calcula la diferencia O(N)
int diferencia(int n , int m){

	if (n>=m)return n-m;
	else return m-n;
}
int main(){
	int numCasos;

	cin >>numCasos;
	
	for (int i = 0; i < numCasos; i++)
	{
		resuelveCaso();
	}
	return 0;
}

