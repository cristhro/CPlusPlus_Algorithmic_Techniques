// Grupo 21, CRISTHIAN RODRIGUEZ GOMEZ y JONATHAN CARRERO ARANDA

//para saber si un Arbol es AVL ademas de que sea equilibrado tambien se cumple que el elemento que almacena en la raiz
// es mayor a todos los elemento de su hijo Izq y asi mismo es menor a todos los elementos de su hijo Derecho.
// para resolver este problema nos ayudamos de la funcion de equilibrio

#include <iostream>
#include "Arbin.h"


using namespace std;

Arbin<int> leeArbol();
int altura(Arbin<int> arbol);
void resuelveCaso(Arbin<int> arbol);
int diferencia(int n , int m);
bool esAVL(Arbin<int> arbol);
bool tiene_2_Hijos(Arbin<int> arbol);
bool tiene_Hijo_Izq(Arbin<int> arbol);
bool tiene_Hijo_Dr(Arbin<int> arbol);

// lee un �rbol binariio de la entrada estandar
Arbin<int> leeArbol()
{
	int raiz;

	cin >> raiz;
	if(raiz==-1)
		return Arbin<int>();
	else
	{
		const Arbin<int> &iz = leeArbol();
		const Arbin<int> &dr = leeArbol();
		return Arbin<int>(iz, raiz, dr);
	}
}


// dado un �rbol binario, calcula si el arbol es AVL, O(LOG(n))
bool esAVL(Arbin<int> arbol){
	
	if(arbol.esVacio()){ 

		return true;

	}else if( tiene_2_Hijos(arbol)){

		if((arbol.raiz() > arbol.hijoIz().raiz()) && (arbol.hijoDr().raiz() > arbol.raiz())){

			return( esAVL(arbol.hijoIz()) &&			
			        esAVL(arbol.hijoDr()) && 
				    diferencia(
								altura(arbol.hijoIz()),
								altura(arbol.hijoDr())
							  ) <=1
				   );
		}else 
			return false;
	
	}else if(tiene_Hijo_Izq(arbol)){

		if (arbol.raiz() > arbol.hijoIz().raiz()){

			return ( esAVL(arbol.hijoIz() ) && ( diferencia(altura(arbol.hijoIz()),0) ) <=1 );
		}else 
			return false;

	}else if(tiene_Hijo_Dr(arbol)){

		if (arbol.raiz() < arbol.hijoDr().raiz()){

			return ( esAVL(arbol.hijoDr()) && diferencia(0,altura(arbol.hijoDr()) ) <=1 );
		}else 
			return false;
	}
	else return true;
}
//Resuelve un cado de prueba, leyendo de la entrada la
//configuracion, y escribiendo la respuesta
void resuelveCaso(){
	Arbin<int> arbol;

	arbol = leeArbol();
	
	if(esAVL(arbol))
		cout <<"SI" << endl;
	else cout <<"NO" << endl;
} 




//--------------- Funciones Auxiliares------------------
bool tiene_2_Hijos(Arbin<int> arbol){
	return (!arbol.hijoIz().esVacio() && !arbol.hijoDr().esVacio());
}
bool tiene_Hijo_Izq(Arbin<int> arbol){
	return (!arbol.hijoIz().esVacio());
}
bool tiene_Hijo_Dr(Arbin<int> arbol){
	return (!arbol.hijoDr().esVacio());
}
// dado un �rbol binario, calcula la altura del arbol, O(N)
int altura(Arbin<int> arbol){
	if (arbol.esVacio()){
		return 0;
	}else{
		return 1 + max(altura(arbol.hijoIz()),altura(arbol.hijoDr()));
	}
}
// dados dos enteros nos calcula la diferencia O(N)
int diferencia(int n , int m){

	if (n>=m)return n-m;
	else return m-n;
}
int main(){
	int numCasos;

	cin >>numCasos;
	
	for (int i = 0; i < numCasos; i++)
	{
		resuelveCaso();
	}
	return 0;
}

