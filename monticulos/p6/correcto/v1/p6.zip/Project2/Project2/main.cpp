﻿// Grupo 21, CRISTHIAN RODRIGUEZ GOMEZ y JONATHAN CARRERO ARANDA

/*
	PRACTICA 6
	¿Es un Monticulo ?
	El problema se resuelve ayudandonos de las funciones auxiliares, ( completo, semicompleto, altura)
	ya que un monticulo es semicompleto y cada elemento es menor o igual al resto de sus hijos.

*/
#include <math.h>
#include <iostream>
#include "Arbin.h"
#include <algorithm>

using namespace std;

Arbin<int> leeArbol();
int altura(Arbin<int> arbol);
void resuelveCaso(Arbin<int> arbol);
bool es_Completo(Arbin<int> arbol);
bool es_Semicompleto(Arbin<int> arbol);
bool es_Monticulo(Arbin<int> arbol);
bool menor_igual(Arbin<int> arbol, int padre);

// lee un árbol binariio de la entrada estandar
Arbin<int> leeArbol()
{
	int raiz;

	cin >> raiz;
	if(raiz==-1)
		return Arbin<int>();
	else
	{
		const Arbin<int> &iz = leeArbol();
		const Arbin<int> &dr = leeArbol();
		return Arbin<int>(iz, raiz, dr);
	}
}


////Resuelve un cado de prueba, leyendo de la entrada la
////configuracion, y escribiendo la respuesta
void resuelveCaso(){
	Arbin<int> arbol;

	arbol = leeArbol();
	//if(esOrdenado(arbol) && esEquilibrado(arbol))
	if(es_Monticulo(arbol))
	cout <<"SI" << endl;
	else cout <<"NO" << endl;
} 


////--------------- Funciones Auxiliares------------------

int altura(Arbin<int> arbol){
	if (arbol.esVacio()){
		return 0;
	}else{
		return 1 + max(altura(arbol.hijoIz()),altura(arbol.hijoDr()));
	}
}


int main(){
	int numCasos;

	cin >>numCasos;
	
	for (int i = 0; i < numCasos; i++)
	{
		resuelveCaso();
	}

	return 0;
}
/*
	Funcion que nos dice si es Monticulo:

	Monticulo es  un arbol binario semicompleto donde cada elemento es menor o igual
	que sus hijos 

*/
bool es_Monticulo(Arbin<int> arbol){
	if(arbol.esVacio()){ 

		return true;

	}else return (	es_Semicompleto(arbol) && 
					menor_igual( arbol.hijoIz(),arbol.raiz() ) &&
					menor_igual( arbol.hijoDr(),arbol.raiz() ) &&
					es_Monticulo( arbol.hijoIz() ) &&
					es_Monticulo( arbol.hijoDr()) );
}

/*
	Funcion que nos dice si es semicompleto:

	es semicompleto si o bien es completo o tiene vacantes una serie de
	posiciones consecutivas del ultimo nivel empezando por la derecha, de tal manera que al rellenar dichas
	posiciones con nuevas hojas se obtiene un arbol completo
*/
bool es_Semicompleto(Arbin<int> arbol){
	if(arbol.esVacio()) 
		return true;
	else if (es_Completo(arbol)) return true;
	else return (
					((altura(arbol.hijoIz())==altura(arbol.hijoDr())) && es_Completo(arbol.hijoIz()) && es_Semicompleto(arbol.hijoDr())) ||
				(   (altura(arbol.hijoIz())==altura(arbol.hijoDr())+1) && es_Completo(arbol.hijoDr()) && es_Semicompleto(arbol.hijoIz()))
				);
		
}
/*
	funcion que averigua si un arbol es completo: 

	es completo cuando todos sus nodos internos tienen dos hijos no vacıos, y todas
	sus hojas estan al mismo nivel.
*/
bool es_Completo(Arbin<int> arbol){
	if(arbol.esVacio()) 
		return true;
	else 
		return (	es_Completo(arbol.hijoIz()) && 
					es_Completo(arbol.hijoDr()) && 
					 (altura(arbol.hijoIz()) == altura(arbol.hijoDr()))
			   );
}

/*
	Funcion que nos sirve para determinar si un elemento es menor o igual que todos los elementos en un arbol binario	
*/
bool menor_igual(Arbin<int> arbol, int padre){
	if(arbol.esVacio()) return true;
	else return (padre <= arbol.raiz() && menor_igual(arbol.hijoDr(),arbol.raiz()) && menor_igual(arbol.hijoIz(),arbol.raiz()));
}